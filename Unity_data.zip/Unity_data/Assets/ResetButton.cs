using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit;
using UnityEngine.XR.Interaction.Toolkit.Interactables;

// 必要なコンポーネントを自動で追加する
[RequireComponent(typeof(XRGrabInteractable))]
public class ResetButton : MonoBehaviour
{
    private XRGrabInteractable grabInteractable;
    private Vector3 initialPosition; // 掴んで離した時に元の位置に戻すため

    void Awake()
    {
        grabInteractable = GetComponent<XRGrabInteractable>();
        initialPosition = transform.position; // 初期位置を記憶

        // 掴まれた瞬間に OnGrabbed メソッドを呼び出す
        grabInteractable.selectEntered.AddListener(OnGrabbed);

        // 離された瞬間に OnReleased メソッドを呼び出す
        grabInteractable.selectExited.AddListener(OnReleased);
    }

    void OnDestroy()
    {
        // オブジェクトが破棄される際にリスナーを解除
        if (grabInteractable != null)
        {
            grabInteractable.selectEntered.RemoveListener(OnGrabbed);
            grabInteractable.selectExited.RemoveListener(OnReleased);
        }
    }

    // 掴まれた時に実行される処理
    private void OnGrabbed(SelectEnterEventArgs args)
    {
        // GameManagerが存在し、かつゲームがプレイ中の場合のみリセットを実行
        if (GameManager.Instance != null)
        {
            GameManager.Instance.ResetGameDuringPlay();
        }
        else
        {
            Debug.LogError("GameManagerが見つかりません！");
        }
    }

    // 離された時に実行される処理
    private void OnReleased(SelectExitEventArgs args)
    {
        // 物理演算の影響をリセットし、ボタンを元の位置に戻す
        Rigidbody rb = GetComponent<Rigidbody>();
        if (rb != null)
        {
            rb.linearVelocity = Vector3.zero;
            rb.angularVelocity = Vector3.zero;
        }
        transform.position = initialPosition;
    }
}