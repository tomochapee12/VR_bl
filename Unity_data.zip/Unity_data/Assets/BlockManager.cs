using UnityEngine;
using System.Collections.Generic;
using System.Linq;
using UnityEngine.XR.Interaction.Toolkit.Interactables;

public class BlockManager : MonoBehaviour
{
    [System.Serializable]
    public class BlockSpawnInfo
    {
        public GameObject blockPrefab;
        public Vector3 spawnPosition;
        public Quaternion spawnRotation;
    }

    [Header("生成するブロックの情報")]
    public List<BlockSpawnInfo> initialBlockSpawns = new List<BlockSpawnInfo>();

    [Header("ブロック設定")]
    public string blockTag = "Block";

    [Header("積み木エリア設定")]
    public Collider 積み木エリアCollider;

    // 現在シーンに存在するブロックを管理するリスト
    private List<GameObject> currentBlocks = new List<GameObject>();

    private float currentMaxHeight = 0f;
    private int blocksOnAreaCount = 0;

    void Start()
    {
        ResetBlocks();
    }
    
    void Update()
    {
        CalculateMetrics();
    }

    /// <summary>
    /// 全てのブロックをリセットします。
    /// </summary>
    public void ResetBlocks()
    {
        // 1. タグを使って、現在シーンに存在する"Block"を全て見つけ出す
        GameObject[] allBlocksInScene = GameObject.FindGameObjectsWithTag(blockTag);

        // 2. 見つけ出したブロックを全て削除する
        foreach (GameObject block in allBlocksInScene)
        {
            Destroy(block);
        }
        // 3. 管理リストをクリアする
        currentBlocks.Clear();

        // 4. Inspectorで設定された情報に基づいて、新しい初期ブロックを生成
        foreach (var spawnInfo in initialBlockSpawns)
        {
            if (spawnInfo.blockPrefab != null)
            {
                GameObject newBlock = Instantiate(spawnInfo.blockPrefab, spawnInfo.spawnPosition, spawnInfo.spawnRotation);
                currentBlocks.Add(newBlock); // 新しく生成したブロックをリストに追加
            }
        }

        // 5. メトリクスを再計算して表示を0にする
        CalculateMetrics();
    }


    /// <summary>
    /// 全てのブロックの操作可否（掴めるか）とスポナー機能の有効/無効をまとめて設定します。
    /// </summary>
    public void SetBlocksAndSpawnersState(bool isEnabled)
    {
        SetBlocksInteractable(isEnabled);
        SetSpawnersEnabled(isEnabled);
    }

    /// <summary>
    /// 全てのブロックの操作可否（掴めるか）を設定します。
    /// </summary>
    public void SetBlocksInteractable(bool isInteractable)
    {
        GameObject[] allBlocksInScene = GameObject.FindGameObjectsWithTag(blockTag);
        foreach (var block in allBlocksInScene)
        {
            if (block != null && block.TryGetComponent<XRGrabInteractable>(out var interactable))
            {
                interactable.enabled = isInteractable;
            }
        }
    }

    /// <summary>
    /// 全てのブロックのStickySpawnerの有効/無効を設定します。
    /// </summary>
    public void SetSpawnersEnabled(bool isEnabled)
    {
        GameObject[] allBlocksInScene = GameObject.FindGameObjectsWithTag(blockTag);
        foreach (var block in allBlocksInScene)
        {
            if (block != null && block.TryGetComponent<StickySpawner>(out var spawner))
            {
                spawner.enabled = isEnabled;
                if (isEnabled)
                {
                    spawner.UpdateInitialPosition();
                }
            }
        }
    }
    void CalculateMetrics()
    {
        List<GameObject> blocksOnArea = new List<GameObject>();
        blocksOnAreaCount = 0;

        if (積み木エリアCollider == null) return;

        Bounds areaBounds = 積み木エリアCollider.bounds;
        float areaTopY = areaBounds.max.y;

        // 計算時もタグで全検索するのが確実
        GameObject[] allBlocksInScene = GameObject.FindGameObjectsWithTag(blockTag);

        foreach (GameObject block in allBlocksInScene)
        {
            Collider blockCollider = block.GetComponent<Collider>();
            if (blockCollider == null) continue;

            // （以下、計算ロジックは変更なし）
            Bounds blockBounds = blockCollider.bounds;
            Vector3 blockBaseCenter = new Vector3(blockBounds.center.x, blockBounds.min.y, blockBounds.center.z);

            bool isInHorizontalArea =
                blockBaseCenter.x >= areaBounds.min.x && blockBaseCenter.x <= areaBounds.max.x &&
                blockBaseCenter.z >= areaBounds.min.z && blockBaseCenter.z <= areaBounds.max.z;

            float epsilon = 0.01f;
            bool isAboveAreaTop = blockBounds.min.y >= areaTopY - epsilon;

            if (isInHorizontalArea && isAboveAreaTop)
            {
                blocksOnArea.Add(block);
            }
        }
        
        blocksOnAreaCount = blocksOnArea.Count;
        currentMaxHeight = 0f;
        if (blocksOnArea.Count > 0)
        {
            currentMaxHeight = areaTopY;
            foreach (GameObject blockInArea in blocksOnArea)
            {
                Collider blockInAreaCollider = blockInArea.GetComponent<Collider>();
                if (blockInAreaCollider != null)
                {
                    float blockTopY = blockInAreaCollider.bounds.max.y;
                    if (blockTopY > currentMaxHeight)
                    {
                        currentMaxHeight = blockTopY;
                    }
                }
            }
        }

        if (blocksOnArea.Count == 0)
        {
            currentMaxHeight = 0f;
        }
    }

    public float GetCurrentMaxHeight() { return currentMaxHeight; }
    public int GetBlocksOnAreaCount() { return blocksOnAreaCount; }
}