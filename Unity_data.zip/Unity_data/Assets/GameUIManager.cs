using UnityEngine;
using TMPro;

public class GameUIManager : MonoBehaviour
{
    [Header("UI Text Elements")]
    public TextMeshProUGUI countText;  // 積み木の数を表示するテキスト
    public TextMeshProUGUI heightText; // 積み木の最大の高さを表示するテキスト
    public TextMeshProUGUI commentText; //コメントを表示するテキスト

    [Header("参照するマネージャー")]
    public BlockManager blockManager; // 数と高さを計算するBlockManager

    void Update()
    {
        // GameManagerで isGameActive をチェックし、ゲーム中のみUIを更新するのが理想的
        // ここではシンプルに毎フレーム更新します
        if (GameManager.Instance != null && GameManager.Instance.IsGameActive())
        {
            UpdateScoreUI();
        }
    }

    /// <summary>
    /// BlockManagerから最新の情報を取得し、UIテキストを更新する
    /// </summary>
    private void UpdateScoreUI()
    {
        // BlockManagerが設定されていなければ何もしない
        if (blockManager == null)
        {
            Debug.LogWarning("GameUIManagerにBlockManagerが設定されていません。");
            return;
        }

        // 数と高さを取得
        int blockCount = blockManager.GetBlocksOnAreaCount();
        float maxHeight = blockManager.GetCurrentMaxHeight();

        // テキストを更新
        if (countText != null)
        {
            countText.text = "エリア内の個数: " + blockCount.ToString();
        }

        if (heightText != null)
        {
            // "F2"は小数点以下2桁まで表示するという意味
            heightText.text = "積み上げた高さ: " + maxHeight.ToString("F2") + "m";
        }
    }

    /// <summary>
    /// ゲーム開始/終了時にUIをリセットする
    /// </summary>
    public void ResetScoreUI()
    {
        if (countText != null)
        {
            countText.text = "エリア内の個数: 0";
        }
        if (heightText != null)
        {
            heightText.text = "積み上げた高さ: 0.00m";
        }
    }

    /// <summary>
    /// コメント用テキストに指定した文字列を表示します
    /// </summary>
    public void SetCommentText(string message)
    {
        if (commentText != null)
        {
            commentText.text = message;
        }
    }
}