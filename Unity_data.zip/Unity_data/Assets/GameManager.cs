using System.Collections;
using UnityEngine;
using TMPro;

public class GameManager : MonoBehaviour
{
    // --- 変数宣言 ---
    public static GameManager Instance { get; private set; }
    [Header("Audio")]
    public AudioClip countdownSound;
    private AudioSource audioSource;
    [Header("Managers")]
    public BlockManager blockManager;
    public GameUIManager uiManager;
    [Header("UI Elements")]
    public TextMeshProUGUI countdownText;
    public TextMeshProUGUI timerText;
    [Header("Game Objects")]
    public GameObject startObject;
    public GameObject resetButtonObject;
    [Header("Game Settings")]
    public float gameDuration = 180f;
    private bool isGameActive = false;
    private float timeLeft;
    private bool hasShown30SecondWarning = false;

    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
        audioSource = GetComponent<AudioSource>();
        if (audioSource == null)
        {
            Debug.LogWarning("GameManagerにAudioSourceがありません。自動的に追加します。");
            audioSource = gameObject.AddComponent<AudioSource>();
        }
    }

    void Start()
    {
        // 起動時に一度だけ、ゲームの準備を完了させる
        PrepareForNewGame();
    }

    // --- 唯一の初期化メソッド ---
    private void PrepareForNewGame()
    {
        isGameActive = false;

        // UIの初期状態
        if (countdownText != null) countdownText.gameObject.SetActive(false);
        if (timerText != null) timerText.gameObject.SetActive(false);
        if (uiManager != null)
        {
            uiManager.SetCommentText("青いボールでスタート　黄色いボールでリセット");
        }

        // ゲームオブジェクトの初期状態
        if (startObject != null) startObject.SetActive(true);
        if (resetButtonObject != null) resetButtonObject.SetActive(false);

        // ブロックの初期状態
        if (blockManager != null)
        {
            blockManager.ResetBlocks();
            blockManager.SetBlocksAndSpawnersState(false);
        }
    }

    void Update()
    {
        if (isGameActive)
        {
            if (timeLeft > 0)
            {
                timeLeft -= Time.deltaTime;
                if (!hasShown30SecondWarning && timeLeft <= 30.0f)
                {
                    if (uiManager != null)
                    {
                        uiManager.SetCommentText("残り時間はあと少しです。");
                    }
                    hasShown30SecondWarning = true;
                }
                UpdateTimerDisplay();
            }
            else
            {
                isGameActive = false;
                GameOver();
            }
        }
    }
    
    public void StartGame()
    {
        if (isGameActive) return;
        if (countdownSound != null && audioSource != null)
        {
            audioSource.PlayOneShot(countdownSound);
        }
        if (startObject != null)
        {
            startObject.SetActive(false);
        }
        StartCoroutine(CountdownCoroutine());
    }

    private IEnumerator CountdownCoroutine()
    {
        if (uiManager != null)
        {
            uiManager.ResetScoreUI();
            uiManager.SetCommentText("");
        }
        blockManager.ResetBlocks();
        blockManager.SetSpawnersEnabled(true);
        countdownText.gameObject.SetActive(true);
        countdownText.text = "3";
        yield return new WaitForSeconds(1f);
        countdownText.text = "2";
        yield return new WaitForSeconds(1f);
        countdownText.text = "1";
        yield return new WaitForSeconds(1f);
        countdownText.text = "START!";
        blockManager.SetBlocksInteractable(true);
        yield return new WaitForSeconds(1f);
        countdownText.gameObject.SetActive(false);
        isGameActive = true;
        timeLeft = gameDuration;
        timerText.gameObject.SetActive(true);
        if (resetButtonObject != null) resetButtonObject.SetActive(true);
        hasShown30SecondWarning = false;
        if (uiManager != null)
        {
            uiManager.SetCommentText("青いボールでスタート　黄色いボールでリセット");
        }
    }

    private void GameOver()
    {
        isGameActive = false;

        if (timerText != null)
        {
            timerText.text = "FINISH!";
            StartCoroutine(HideTextAfterDelay(timerText.gameObject, 3.0f));
        }

        if (uiManager != null)
        {
            uiManager.SetCommentText("タイムアップ！ お疲れさまでした");
        }
        if (resetButtonObject != null)
        {
            resetButtonObject.SetActive(false);
        }

        // 20秒後に準備完了状態に戻すコルーチンを開始
        StartCoroutine(ReturnToReadyStateAfterDelay(10.0f));

        // ブロックはすぐに操作不能にする
        blockManager.SetBlocksAndSpawnersState(false);
    }

    public void ResetGameDuringPlay()
    {
        if (isGameActive)
        {
            blockManager.ResetBlocks();
            blockManager.SetBlocksAndSpawnersState(true);
        }
    }

    private void UpdateTimerDisplay()
    {
        if (timerText == null) return;
        int minutes = Mathf.FloorToInt(timeLeft / 60);
        int seconds = Mathf.FloorToInt(timeLeft % 60);
        timerText.text = string.Format("{0:00}:{1:00}", minutes, seconds);
    }
    
    public bool IsGameActive()
    {
        return isGameActive;
    }
    
    private IEnumerator HideTextAfterDelay(GameObject objToHide, float delay)
    {
        yield return new WaitForSeconds(delay);
        if (objToHide != null)
        {
            objToHide.SetActive(false);
        }
    }
    private IEnumerator ReturnToReadyStateAfterDelay(float delay)
    {
        yield return new WaitForSeconds(delay);

        if (uiManager != null)
        {
            uiManager.SetCommentText("青いボールでスタート　黄色いボールでリセット");
        }
        if (startObject != null)
        {
            startObject.SetActive(true);
        }
        if (resetButtonObject != null)
        {
            resetButtonObject.SetActive(false);
        }
    }
}