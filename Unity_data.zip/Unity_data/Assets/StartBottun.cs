using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit;
using UnityEngine.XR.Interaction.Toolkit.Interactables; // XRGrabInteractableのために必要

// 必要なコンポーネントを自動で追加する
[RequireComponent(typeof(XRGrabInteractable))]
public class StartButton : MonoBehaviour
{
    private XRGrabInteractable grabInteractable;

    void Awake()
    {
        grabInteractable = GetComponent<XRGrabInteractable>();
        
        // 掴まれた瞬間に OnGrabbed メソッドを呼び出すようにイベントを登録
        grabInteractable.selectEntered.AddListener(OnGrabbed);
    }

    // オブジェクトが破棄される際にリスナーを解除（メモリリーク防止）
    void OnDestroy()
    {
        grabInteractable.selectEntered.RemoveListener(OnGrabbed);
    }

    // 掴まれた時に実行される処理
    private void OnGrabbed(SelectEnterEventArgs args)
    {
        // GameManagerが存在すれば、ゲーム開始メソッドを呼び出す
        if (GameManager.Instance != null)
        {
            GameManager.Instance.StartGame();
        }
        else
        {
            Debug.LogError("GameManagerが見つかりません！");
        }

        // 一度掴まれたら、もう反応しないようにイベントの登録を解除する
        //grabInteractable.selectEntered.RemoveListener(OnGrabbed);

        // オプション：掴んだボタンをそのまま消してしまうこともできる
        // gameObject.SetActive(false); 
        // ※GameManager側でも消しているので、どちらかでOK
    }
}